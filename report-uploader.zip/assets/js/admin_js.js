jQuery(document).ready(function ($) {
  if( $( '.select2' ).length > 0 ) {
      $( '.select2' ).select2();
  }
});
