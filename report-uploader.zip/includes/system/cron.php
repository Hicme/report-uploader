<?php

namespace system;

class Cron
{

  public function __construct()
  {

  }



}
