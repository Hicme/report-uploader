<?php get_header(); ?>

<div class="inner-page-wrap clearfix">
  <div class="page-content clearfix">
    <h3><?php _e( 'You do not have permission to view this page.', 'report_uploader' ); ?></h3>
    <div class="link-pages"><?php wp_link_pages(); ?></div>
  </div>
</div>

<?php get_footer(); ?>